AgOpenGPS steering files used with Claas.
