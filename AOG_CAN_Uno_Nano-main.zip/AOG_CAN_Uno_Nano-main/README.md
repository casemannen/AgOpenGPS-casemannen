# AOG_CAN_Uno_Nano
Steering navagation controller files for the Arduino Uno/Nano and the MCP2515 can shield to use with AgOpenGPS

I will add a zip folder for each brand.
