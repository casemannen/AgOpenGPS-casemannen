Tractor simulator for bench testing CAN setup with AgOpenGPS.

Load this onto the Arduino with Pot connected to A0, Switch connected to A1, Button connected to A2.
