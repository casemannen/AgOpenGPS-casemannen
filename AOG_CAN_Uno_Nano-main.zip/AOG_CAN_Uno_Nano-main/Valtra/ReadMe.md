Steering files for Valtra (and Massey Ferguson) Danfoss PVED based steering controllers
