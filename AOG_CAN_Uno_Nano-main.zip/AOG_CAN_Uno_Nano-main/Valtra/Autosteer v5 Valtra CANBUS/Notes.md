Autosteer program for v5 AgOpenGPS 
